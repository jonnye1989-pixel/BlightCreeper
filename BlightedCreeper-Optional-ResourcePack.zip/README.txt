BlightBreak optional Blighted Creeper texture pack

Install this pack on the client (or distribute it through a resource-pack host) and enable it.
It uses the creeper-skin.png uploaded to Main Build and targets the entity named "Blighted Creeper".
Selective named-entity textures require OptiFine or Entity Texture Features (ETF) on the client.
Vanilla clients without these mods will still see the normal creeper; there is no server-side per-entity vanilla texture support.
The storm creeper already has the visible nameplate, glow outline, and ash cue.
