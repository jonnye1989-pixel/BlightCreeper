BlightBreak vanilla-compatible Creeper resource pack

This pack replaces the creeper texture for every creeper with the uploaded custom skin. It works with vanilla clients and does not require OptiFine/ETF.
To deliver it from the server, host this ZIP at a direct public HTTPS URL, then configure server.properties resource-pack=<URL>, resource-pack-sha1=<SHA-1>, and (optionally) require-resource-pack=true.
